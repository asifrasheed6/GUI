package calendar;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JLabel;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
public class DateView extends View{
    private int maxDays, firstDay;
    private JLabel []columns;
    {
        this.setLayout(new GridLayout(5,8));
        columns = new JLabel[35];
        firstDay = 3;
        maxDays = 31;
        
        int pos=6;
        for(int i=0;i<columns.length;i++){
            columns[i]=new JLabel("");
            
            /*The following three lines are to make the border look clean*/
            /*If you are not looking for a clean border, just use:
                columns[i].setBorder(BorderFactory.createLineBorder(Color.black, 1);*/
            if(i==pos){
                columns[i].setBorder(BorderFactory.createMatteBorder(1-pos%6, 0, 1, 0, Color.lightGray));
                pos+=7;
            }
            else if(i>6) columns[i].setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, Color.lightGray));
            else columns[i].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 1, Color.lightGray));
            
            columns[i].setHorizontalAlignment(JLabel.CENTER);
            this.add(columns[i]);
        }
        int k=1;
        for(int i=firstDay-1;k<=maxDays;k++){
            if(i>=columns.length) i=0;
            columns[i++].setText(Integer.toString(k));
        }    
    }
    
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        this.setBackground(Color.white);
    }
    
    public void updateDate(int firstDay, int maxDays, boolean month, int day){
        this.firstDay = firstDay;
        this.maxDays = maxDays;
        
        for(int i=0;i<columns.length;i++)
            columns[i].setText("");
        
        int k=1;
        for(int i=firstDay-1;k<=maxDays;k++){
            if(i>=columns.length) i=0;
            if(i==day-1 && month) columns[i++].setText("<html><font color='red'><b>"+Integer.toString(k)+"</b></font></html>");
            else columns[i++].setText(Integer.toString(k));
        }
        
        repaint();
    }
}
