package calendar;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
public class Days extends View{    
    private JLabel []days;
    private JLabel label, label2;
    private JPanel monthPanel, daysPanel;
            
    {
        days = new JLabel[7];
        
        label = new JLabel("January");
        label.setHorizontalAlignment(JLabel.RIGHT);
        label.setFont(new Font("Arial", Font.BOLD, 24));
        
        label2 = new JLabel("2019");
        label2.setHorizontalAlignment(JLabel.LEFT);
        label2.setFont(new Font("Arial", Font.PLAIN, 24));
        
        String []labels = {"SUN","MON","TUE","WED","THU","FRI","SAT"};
        int i=0;
        
        this.setLayout(new GridLayout(2,1));
        
        monthPanel = new JPanel(new GridLayout(1,2,5,0));
        monthPanel.setBackground(Color.white);
        monthPanel.add(label);
        monthPanel.add(label2);
        
        for(int k=2;k<7;k++)
            monthPanel.add(new JLabel());
        
        this.add(monthPanel);
        
        daysPanel = new JPanel(new GridLayout(1,7,20,20));
        daysPanel.setBackground(Color.white);
        for(String l: labels)
        {
            days[i] = new JLabel(l);
            days[i].setHorizontalAlignment(JLabel.CENTER);
            daysPanel.add(days[i++]);
        }
        this.add(daysPanel);
    }
    
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        this.setBackground(Color.white);
    }
    
    public void updateMonth(String month, String year){
        label.setText(month);
        label2.setText(year);
        repaint();
    }
}
