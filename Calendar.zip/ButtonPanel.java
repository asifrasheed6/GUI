
package calendar;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
public class ButtonPanel extends View{
    private JButton nextMonth, prevMonth, thisMonth;
    
    {
       nextMonth = new JButton("February");
       prevMonth = new JButton("December");
       thisMonth = new JButton("This Month");
       
       this.setLayout(new GridLayout(1,5,20,20));
       
       this.add(new JLabel());
       this.add(prevMonth);
       this.add(thisMonth);
       this.add(nextMonth);
       this.add(new JLabel());
    }
    
    @Override 
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        this.setBackground(Color.white);
    }
    
    public JButton getNextButton(){
        return nextMonth;
    }
    
    public JButton getThisMonthButton(){
        return thisMonth;
    }
    
    public JButton getPrevButton(){
        return prevMonth;
    }
    
    public void updateMonths(String prevMonth, String nextMonth){
        this.nextMonth.setText(nextMonth);
        this.prevMonth.setText(prevMonth);
        repaint();
    }
}
